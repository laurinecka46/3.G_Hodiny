function ukazka (pozdrav) {
    console.log(pozdrav)
    console.log("nazdar")
}

ukazka("dobry den")
